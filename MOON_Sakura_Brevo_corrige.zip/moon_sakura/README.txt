MOON SAKURA — fichiers du site et du panneau admin

FICHIERS
- index.html : site public MOON, thème nuit/violet/blanc avec fleurs sakura et liens Discord/TikTok.
- admin.html : panneau MOON Manager (paramètres, tickets, membres, modération et file de réponses du bot).
- moon_setup.sql : tables, fonctions RPC, permissions et politiques RLS de Supabase.

INSTALLATION
1. Dans Supabase > SQL Editor, exécute moon_setup.sql.
2. Dans Supabase > Authentication > Users, crée ton compte staff avec e-mail et mot de passe.
3. Copie l'UUID de cet utilisateur et exécute dans SQL Editor :
   insert into public.admin_users (user_id) values ('UUID-DU-COMPTE-STAFF');
4. Déploie index.html comme page d'accueil publique et admin.html comme panneau admin sur ton hébergement HTTPS.
5. Dans Supabase > Authentication > URL Configuration, configure l'URL du site comme Site URL et ajoute l'URL de redirection utilisée par Discord OAuth dans les Redirect URLs. Le fournisseur Discord doit aussi être configuré dans Supabase > Authentication > Providers.
6. Ouvre admin.html et connecte-toi avec le compte autorisé; les réglages du site public se font dans Paramètres.

NOTES
- Le compteur indique les navigateurs actifs sur le site pendant les 90 dernières secondes; ce n'est pas le nombre de membres Discord.
- Les tickets s'enregistrent dans Supabase et le staff peut répondre depuis le panneau. Aucun e-mail automatique n'est envoyé.
- Les réponses préparées dans « Messages bot » sont mises en file dans moon_bot_dm_replies. Un bot Discord doit encore lire la file et envoyer les messages; le HTML ne peut pas envoyer de DM Discord directement.
- L'intégration Discord OAuth doit être configurée dans Supabase avant que le bouton « Connexion Discord » fonctionne.
- La clé sb_publishable_ utilisée dans le navigateur est une clé publique. Ne place jamais une clé service_role ou un secret Supabase dans les fichiers HTML.
- Le SQL retire les politiques RLS préexistantes sur les tables MOON listées puis recrée des politiques staff/public ciblées. Vérifie les dépendances propres à ton projet avant de l'exécuter sur une base de production existante.
