import { createClient } from "npm:@supabase/supabase-js@2";

const ALLOWED_ORIGIN = "https://moon-manager.pages.dev";
const corsHeaders = {
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-api-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Vary": "Origin",
};

function json(status: number, body: Record<string, unknown>): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
  });
}

function escapeHtml(value: string): string {
  const entities: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  };
  return value.replace(/[&<>"']/g, (char) => entities[char] ?? char);
}

function getPublishableKey(): string | null {
  const legacyKey = Deno.env.get("SUPABASE_ANON_KEY");
  if (legacyKey) return legacyKey;

  const directKey = Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
  if (directKey) return directKey;

  const jsonKeys = Deno.env.get("SUPABASE_PUBLISHABLE_KEYS");
  if (jsonKeys) {
    try {
      const parsed = JSON.parse(jsonKeys);
      if (typeof parsed.default === "string") return parsed.default;
      const firstString = Object.values(parsed).find((value) => typeof value === "string");
      if (typeof firstString === "string") return firstString;
    } catch (error) {
      console.error("Impossible de lire SUPABASE_PUBLISHABLE_KEYS", error);
    }
  }
  return null;
}

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (request.method !== "POST") {
    return json(405, { ok: false, error: "Méthode non autorisée." });
  }

  const origin = request.headers.get("origin");
  if (origin && origin !== ALLOWED_ORIGIN) {
    return json(403, { ok: false, error: "Origine non autorisée." });
  }

  const authorization = request.headers.get("authorization");
  if (!authorization?.startsWith("Bearer ")) {
    return json(401, { ok: false, error: "Connexion staff requise." });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const publishableKey = getPublishableKey();
  const brevoApiKey = Deno.env.get("BREVO_API_KEY");
  const fromEmail = Deno.env.get("BREVO_FROM_EMAIL");
  const fromName = Deno.env.get("BREVO_FROM_NAME") || "MOON Community";

  if (!supabaseUrl || !publishableKey) {
    console.error("Variables Supabase manquantes.");
    return json(500, { ok: false, error: "Configuration Supabase incomplète." });
  }
  if (!brevoApiKey || !fromEmail) {
    return json(503, {
      ok: false,
      error: "Secrets manquants : BREVO_API_KEY et BREVO_FROM_EMAIL doivent être configurés.",
    });
  }

  try {
    const supabase = createClient(supabaseUrl, publishableKey, {
      global: { headers: { Authorization: authorization } },
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: authData, error: authError } = await supabase.auth.getUser();
    const user = authData?.user;
    if (authError || !user) {
      return json(401, { ok: false, error: "Session expirée. Reconnecte-toi au panneau admin." });
    }

    const { data: adminRow, error: adminError } = await supabase
      .from("admin_users")
      .select("user_id")
      .eq("user_id", user.id)
      .maybeSingle();

    if (adminError || !adminRow) {
      return json(403, { ok: false, error: "Ce compte n'est pas autorisé à envoyer des réponses." });
    }

    let payload: { ticket_id?: unknown; reply?: unknown };
    try {
      payload = await request.json();
    } catch {
      return json(400, { ok: false, error: "Corps JSON invalide." });
    }

    const ticketId = typeof payload.ticket_id === "string" ? payload.ticket_id : "";
    const reply = typeof payload.reply === "string" ? payload.reply.trim() : "";
    const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

    if (!uuidPattern.test(ticketId)) {
      return json(400, { ok: false, error: "Identifiant du ticket invalide." });
    }
    if (!reply || reply.length > 5000) {
      return json(400, { ok: false, error: "La réponse doit contenir entre 1 et 5 000 caractères." });
    }

    const { data: ticket, error: ticketError } = await supabase
      .from("moon_support_tickets")
      .select("id, name, email, subject")
      .eq("id", ticketId)
      .maybeSingle();

    if (ticketError || !ticket) {
      console.error("Ticket inaccessible ou introuvable", ticketError);
      return json(404, { ok: false, error: "Ticket introuvable ou accès refusé." });
    }

    if (typeof ticket.email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(ticket.email)) {
      return json(400, { ok: false, error: "L'adresse e-mail du ticket n'est pas valide." });
    }

    const name = String(ticket.name || "membre MOON");
    const subjectText = String(ticket.subject || "Support").replace(/[\r\n]/g, " ").slice(0, 150);
    const safeName = escapeHtml(name);
    const safeSubject = escapeHtml(subjectText);
    const safeReply = escapeHtml(reply).replace(/\r?\n/g, "<br>");

    const brevoResponse = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "api-key": brevoApiKey,
        "accept": "application/json",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        sender: { name: fromName, email: fromEmail },
        to: [{ email: ticket.email, name }],
        subject: `Réponse à ton ticket MOON : ${subjectText}`,
        textContent:
          `Bonjour ${name},\n\n` +
          `Le staff MOON a répondu à ton ticket « ${subjectText} » :\n\n` +
          `${reply}\n\n— L’équipe MOON · Made by Santa ✿`,
        htmlContent: `
          <div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;color:#32204f;line-height:1.6">
            <div style="background:#f5efff;border-radius:16px;padding:22px">
              <h1 style="margin:0;color:#6d28d9">🌸 MOON Support</h1>
              <p>Bonjour ${safeName}, le staff a répondu à ton ticket.</p>
              <p><strong>Sujet :</strong> ${safeSubject}</p>
              <div style="background:#fff;border:1px solid #e8def6;border-radius:12px;padding:16px">${safeReply}</div>
              <p>— L’équipe MOON · Made by Santa ✿</p>
            </div>
          </div>`,
      }),
    });

    const brevoBody = await brevoResponse.json().catch(() => ({}));
    if (!brevoResponse.ok) {
      console.error("Brevo a refusé l'envoi", brevoResponse.status, brevoBody);
      return json(502, {
        ok: false,
        error: "Brevo a refusé l'envoi. Vérifie la clé API, l'expéditeur et les journaux de la fonction.",
      });
    }

    return json(200, {
      ok: true,
      to: ticket.email,
      email_id: brevoBody.messageId ?? null,
      message: "Brevo a accepté la demande d'envoi.",
    });
  } catch (error) {
    console.error("Erreur send-ticket-reply", error);
    return json(500, { ok: false, error: "Erreur interne pendant l'envoi." });
  }
});
