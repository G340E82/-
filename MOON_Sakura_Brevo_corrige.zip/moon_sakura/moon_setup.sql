-- MOON Sakura — base de données Supabase
-- Exécuter dans Supabase > SQL Editor. Ne jamais placer une clé service_role dans le HTML.

create extension if not exists pgcrypto;

-- 1) Tables
create table if not exists public.moon_site_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.moon_members (
  id uuid primary key default gen_random_uuid(),
  discord_id text not null unique,
  username text not null,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.moon_moderation_cases (
  id uuid primary key default gen_random_uuid(),
  username text not null,
  reason text not null,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists public.moon_support_tickets (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  subject text not null,
  message text not null,
  status text not null default 'open',
  admin_reply text,
  created_at timestamptz not null default now()
);

create table if not exists public.moon_bot_dms (
  id uuid primary key default gen_random_uuid(),
  discord_user_id text not null,
  username text,
  message text not null,
  status text not null default 'new',
  received_at timestamptz not null default now()
);

create table if not exists public.moon_site_visitors (
  visitor_id text primary key,
  last_seen timestamptz not null default now()
);

-- Migrations non destructives : ajoute les champs utilisés par les deux pages si une table existe déjà.
-- Les types des colonnes préexistantes ne sont volontairement pas changés automatiquement.
alter table public.moon_members add column if not exists id uuid default gen_random_uuid();
alter table public.moon_members add column if not exists discord_id text;
alter table public.moon_members add column if not exists username text;
alter table public.moon_moderation_cases add column if not exists id uuid default gen_random_uuid();
alter table public.moon_support_tickets add column if not exists id uuid default gen_random_uuid();
alter table public.moon_bot_dms add column if not exists id uuid default gen_random_uuid();
alter table public.moon_bot_dms add column if not exists discord_user_id text;
alter table public.moon_site_settings add column if not exists value jsonb not null default '{}'::jsonb;
alter table public.moon_site_settings add column if not exists updated_at timestamptz not null default now();
alter table public.moon_members add column if not exists notes text;
alter table public.moon_members add column if not exists created_at timestamptz not null default now();
alter table public.moon_moderation_cases add column if not exists username text;
alter table public.moon_moderation_cases add column if not exists reason text;
alter table public.moon_moderation_cases add column if not exists status text not null default 'open';
alter table public.moon_moderation_cases add column if not exists created_at timestamptz not null default now();
alter table public.moon_support_tickets add column if not exists name text;
alter table public.moon_support_tickets add column if not exists email text;
alter table public.moon_support_tickets add column if not exists subject text;
alter table public.moon_support_tickets add column if not exists message text;
alter table public.moon_support_tickets add column if not exists status text not null default 'open';
alter table public.moon_support_tickets add column if not exists admin_reply text;
alter table public.moon_support_tickets add column if not exists created_at timestamptz not null default now();
alter table public.moon_bot_dms add column if not exists discord_user_id text;
alter table public.moon_bot_dms add column if not exists username text;
alter table public.moon_bot_dms add column if not exists message text;
alter table public.moon_bot_dms add column if not exists status text not null default 'new';
alter table public.moon_bot_dms add column if not exists received_at timestamptz not null default now();
-- Garantit que la clé référencée existe avant de créer la file de réponses.
create unique index if not exists moon_bot_dms_id_uidx on public.moon_bot_dms(id);

create table if not exists public.moon_bot_dm_replies (
  id uuid primary key default gen_random_uuid(),
  dm_id uuid not null references public.moon_bot_dms(id) on delete cascade,
  reply text not null,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

alter table public.moon_bot_dm_replies add column if not exists id uuid default gen_random_uuid();
alter table public.moon_bot_dm_replies add column if not exists dm_id uuid;
alter table public.moon_bot_dm_replies add column if not exists reply text;
alter table public.moon_bot_dm_replies add column if not exists status text not null default 'pending';
alter table public.moon_bot_dm_replies add column if not exists created_at timestamptz not null default now();

-- Upsert des membres par ID Discord et recherches efficaces pour les vues admin.
create unique index if not exists moon_members_id_uidx on public.moon_members(id);
create unique index if not exists moon_members_discord_id_uidx on public.moon_members(discord_id);
create unique index if not exists moon_moderation_cases_id_uidx on public.moon_moderation_cases(id);
create unique index if not exists moon_support_tickets_id_uidx on public.moon_support_tickets(id);
create unique index if not exists moon_bot_dms_id_uidx on public.moon_bot_dms(id);
create unique index if not exists moon_bot_dm_replies_id_uidx on public.moon_bot_dm_replies(id);
create index if not exists moon_tickets_created_at_idx on public.moon_support_tickets(created_at desc);
create index if not exists moon_cases_created_at_idx on public.moon_moderation_cases(created_at desc);
create index if not exists moon_dms_received_at_idx on public.moon_bot_dms(received_at desc);
create index if not exists moon_dm_replies_status_idx on public.moon_bot_dm_replies(status, created_at);
create index if not exists moon_visitors_last_seen_idx on public.moon_site_visitors(last_seen desc);

-- Configuration initiale. Si la clé main existe déjà, elle est préservée.
insert into public.moon_site_settings (key, value)
values (
  'main',
  jsonb_build_object(
    'site_name', 'MOON',
    'site_bio', 'Une communauté pour jouer, échanger et découvrir de nouveaux univers. Rejoins-nous et trouve ta place sous la lune.',
    'discord_invite', 'https://discord.gg/Czs4bTjP',
    'tiktok_url', 'https://www.tiktok.com/@moon.11646',
    'primary_color', '#d98fc5',
    'background_color', '#100b19'
  )
)
on conflict (key) do nothing;

-- 2) Fonction de vérification staff. SECURITY DEFINER évite la récursion de la politique RLS.
create or replace function public.moon_is_admin()
returns boolean
language sql
stable
security definer
set search_path = pg_catalog, public
as $$
  select exists (
    select 1 from public.admin_users au where au.user_id = auth.uid()
  );
$$;

-- 3) Envoi public d'un ticket sans donner au public le droit de lire les tickets.
create or replace function public.create_moon_support_ticket(
  p_name text,
  p_email text,
  p_subject text,
  p_message text
)
returns uuid
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  new_id uuid;
  clean_name text := btrim(coalesce(p_name, ''));
  clean_email text := btrim(coalesce(p_email, ''));
  clean_subject text := btrim(coalesce(p_subject, ''));
  clean_message text := btrim(coalesce(p_message, ''));
begin
  if char_length(clean_name) not between 1 and 80 then
    raise exception 'Pseudo invalide.';
  end if;
  if char_length(clean_email) not between 3 and 254
     or clean_email !~ '^[^[:space:]@]+@[^[:space:]@]+[.][^[:space:]@]+$' then
    raise exception 'Adresse e-mail invalide.';
  end if;
  if char_length(clean_subject) not between 1 and 120 then
    raise exception 'Sujet invalide.';
  end if;
  if char_length(clean_message) not between 1 and 5000 then
    raise exception 'Message invalide.';
  end if;

  insert into public.moon_support_tickets(name, email, subject, message, status)
  values (clean_name, clean_email, clean_subject, clean_message, 'open')
  returning id into new_id;

  return new_id;
end;
$$;

-- 4) Compteur des visiteurs actifs (les pages envoient un heartbeat toutes les 25 secondes).
create or replace function public.moon_visitor_heartbeat(p_visitor_id text)
returns void
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
begin
  if p_visitor_id is null or char_length(p_visitor_id) < 8 or char_length(p_visitor_id) > 120 then
    raise exception 'Identifiant visiteur invalide.';
  end if;

  insert into public.moon_site_visitors(visitor_id, last_seen)
  values (p_visitor_id, now())
  on conflict (visitor_id) do update set last_seen = excluded.last_seen;

end;
$$;

create or replace function public.moon_online_count()
returns integer
language sql
stable
security definer
set search_path = pg_catalog, public
as $$
  select count(*)::integer
  from public.moon_site_visitors
  where last_seen >= now() - interval '90 seconds';
$$;

-- 5) RLS : remplace les politiques existantes de ces tables pour éviter qu'une ancienne policy
-- permissive continue d'autoriser l'accès public par inadvertance.
do $$
declare
  pol record;
begin
  for pol in
    select schemaname, tablename, policyname
    from pg_policies
    where schemaname = 'public'
      and tablename = any (array[
        'moon_site_settings', 'admin_users', 'moon_members', 'moon_moderation_cases',
        'moon_support_tickets', 'moon_bot_dms', 'moon_bot_dm_replies', 'moon_site_visitors'
      ])
  loop
    execute format('drop policy if exists %I on %I.%I', pol.policyname, pol.schemaname, pol.tablename);
  end loop;
end $$;

alter table public.moon_site_settings enable row level security;
alter table public.admin_users enable row level security;
alter table public.moon_members enable row level security;
alter table public.moon_moderation_cases enable row level security;
alter table public.moon_support_tickets enable row level security;
alter table public.moon_bot_dms enable row level security;
alter table public.moon_bot_dm_replies enable row level security;
alter table public.moon_site_visitors enable row level security;

-- Paramètres publics lisibles; seuls les comptes staff autorisés peuvent les modifier.
create policy moon_settings_public_read on public.moon_site_settings
  for select to anon, authenticated using (key = 'main');
create policy moon_settings_admin_all on public.moon_site_settings
  for all to authenticated using (public.moon_is_admin())
  with check (public.moon_is_admin());

-- Un utilisateur connecté peut vérifier sa propre entrée; le staff gère la liste.
create policy moon_admin_users_read_own on public.admin_users
  for select to authenticated using (user_id = auth.uid());
create policy moon_admin_users_admin_all on public.admin_users
  for all to authenticated using (public.moon_is_admin())
  with check (public.moon_is_admin());

-- Toutes les données opérationnelles sont accessibles uniquement au staff.
create policy moon_members_admin_all on public.moon_members
  for all to authenticated using (public.moon_is_admin()) with check (public.moon_is_admin());
create policy moon_cases_admin_all on public.moon_moderation_cases
  for all to authenticated using (public.moon_is_admin()) with check (public.moon_is_admin());
create policy moon_tickets_admin_all on public.moon_support_tickets
  for all to authenticated using (public.moon_is_admin()) with check (public.moon_is_admin());
create policy moon_dms_admin_all on public.moon_bot_dms
  for all to authenticated using (public.moon_is_admin()) with check (public.moon_is_admin());
create policy moon_dm_replies_admin_all on public.moon_bot_dm_replies
  for all to authenticated using (public.moon_is_admin()) with check (public.moon_is_admin());
-- Aucun accès direct aux visiteurs : lecture et écriture passent par les RPC ci-dessus.

-- 6) Privilèges minimaux. La RLS reste obligatoire en complément des GRANT.
grant usage on schema public to anon, authenticated;
revoke all on public.moon_site_settings, public.admin_users, public.moon_members,
  public.moon_moderation_cases, public.moon_support_tickets, public.moon_bot_dms,
  public.moon_bot_dm_replies, public.moon_site_visitors from anon, authenticated;

grant select on public.moon_site_settings to anon, authenticated;
grant insert, update, delete on public.moon_site_settings to authenticated;
grant select, insert, update, delete on public.admin_users, public.moon_members,
  public.moon_moderation_cases, public.moon_support_tickets, public.moon_bot_dms,
  public.moon_bot_dm_replies to authenticated;

revoke all on function public.moon_is_admin() from public, anon;
grant execute on function public.moon_is_admin() to authenticated;
revoke all on function public.create_moon_support_ticket(text, text, text, text) from public, anon, authenticated;
grant execute on function public.create_moon_support_ticket(text, text, text, text) to anon, authenticated;
revoke all on function public.moon_visitor_heartbeat(text) from public, anon, authenticated;
grant execute on function public.moon_visitor_heartbeat(text) to anon, authenticated;
revoke all on function public.moon_online_count() from public, anon, authenticated;
grant execute on function public.moon_online_count() to anon, authenticated;

-- IMPORTANT : crée un utilisateur dans Supabase Auth, récupère son UUID, puis exécute :
-- insert into public.admin_users (user_id) values ('UUID-DU-COMPTE-STAFF');
